package cn.cyc.mapper;

import cn.cyc.pojo.TAcctSourceMiLoanInfo;
import cn.cyc.pojo.TAcctSourceMiLoanInfoExample;
import java.math.BigDecimal;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TAcctSourceMiLoanInfoMapper {
    long countByExample(TAcctSourceMiLoanInfoExample example);

    int deleteByExample(TAcctSourceMiLoanInfoExample example);

    int deleteByPrimaryKey(BigDecimal id);

    int insert(TAcctSourceMiLoanInfo record);

    int insertSelective(TAcctSourceMiLoanInfo record);

    List<TAcctSourceMiLoanInfo> selectByExample(TAcctSourceMiLoanInfoExample example);

    TAcctSourceMiLoanInfo selectByPrimaryKey(BigDecimal id);

    int updateByExampleSelective(@Param("record") TAcctSourceMiLoanInfo record, @Param("example") TAcctSourceMiLoanInfoExample example);

    int updateByExample(@Param("record") TAcctSourceMiLoanInfo record, @Param("example") TAcctSourceMiLoanInfoExample example);

    int updateByPrimaryKeySelective(TAcctSourceMiLoanInfo record);

    int updateByPrimaryKey(TAcctSourceMiLoanInfo record);
}