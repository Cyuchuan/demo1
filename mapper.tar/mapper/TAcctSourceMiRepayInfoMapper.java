package cn.cyc.mapper;

import cn.cyc.pojo.TAcctSourceMiRepayInfo;
import cn.cyc.pojo.TAcctSourceMiRepayInfoExample;
import java.math.BigDecimal;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TAcctSourceMiRepayInfoMapper {
    long countByExample(TAcctSourceMiRepayInfoExample example);

    int deleteByExample(TAcctSourceMiRepayInfoExample example);

    int deleteByPrimaryKey(BigDecimal id);

    int insert(TAcctSourceMiRepayInfo record);

    int insertSelective(TAcctSourceMiRepayInfo record);

    List<TAcctSourceMiRepayInfo> selectByExample(TAcctSourceMiRepayInfoExample example);

    TAcctSourceMiRepayInfo selectByPrimaryKey(BigDecimal id);

    int updateByExampleSelective(@Param("record") TAcctSourceMiRepayInfo record, @Param("example") TAcctSourceMiRepayInfoExample example);

    int updateByExample(@Param("record") TAcctSourceMiRepayInfo record, @Param("example") TAcctSourceMiRepayInfoExample example);

    int updateByPrimaryKeySelective(TAcctSourceMiRepayInfo record);

    int updateByPrimaryKey(TAcctSourceMiRepayInfo record);
}