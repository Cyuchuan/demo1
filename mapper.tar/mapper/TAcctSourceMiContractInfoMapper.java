package cn.cyc.mapper;

import cn.cyc.pojo.TAcctSourceMiContractInfo;
import cn.cyc.pojo.TAcctSourceMiContractInfoExample;
import java.math.BigDecimal;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TAcctSourceMiContractInfoMapper {
    long countByExample(TAcctSourceMiContractInfoExample example);

    int deleteByExample(TAcctSourceMiContractInfoExample example);

    int deleteByPrimaryKey(BigDecimal id);

    int insert(TAcctSourceMiContractInfo record);

    int insertSelective(TAcctSourceMiContractInfo record);

    List<TAcctSourceMiContractInfo> selectByExample(TAcctSourceMiContractInfoExample example);

    TAcctSourceMiContractInfo selectByPrimaryKey(BigDecimal id);

    int updateByExampleSelective(@Param("record") TAcctSourceMiContractInfo record, @Param("example") TAcctSourceMiContractInfoExample example);

    int updateByExample(@Param("record") TAcctSourceMiContractInfo record, @Param("example") TAcctSourceMiContractInfoExample example);

    int updateByPrimaryKeySelective(TAcctSourceMiContractInfo record);

    int updateByPrimaryKey(TAcctSourceMiContractInfo record);
}